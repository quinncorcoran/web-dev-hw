<strong>1.What is the difference between padding, margin, and borders? </strong>
<br> <em> Padding </em> nis the space between one element and the next. <em> Margin </em> is the space that is between each element and the edge of the screen. <em> Borders </em> are the edges of an element that frame the element.  


<strong> 2. Embed the image of your sketch. image icon</strong>
<img src="/images/site-sketch.jpg">


<strong>Free Response: Summarize your work cycle for this assignment. </strong>
<br> <em> A lot of trial, error, mostly error and taking what I could from examples in the online course and applying it to what I wanted. 
