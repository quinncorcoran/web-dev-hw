<strong>1. Describe the difference between the universal, element, class, and id selector types. When might you choose one over the other to style content?</strong>
  <br> <em> Universal Selector</em> is used to edit t he style of every element on the page. It uses a star or asterisk to denote "all".
  <br> <em> Element Selector</em> is used for each specific element. Such as if we want every heading or paragraph to be one color or have the same border, we would use the element selector.
  <br><em> Class Selector</em> would be used to select specific elements. Such as different paragraphs or sections on the page.
  <br><em> ID Selector</em> is similar to class selector where each section has their own "ID" and that is how they are edited. Unlike Class Selectors which start with ".", ID Selectors start with "#" to denote the beginning.

<strong>2. Briefly discuss your color palette, including the 3 colors you chose. List their color names, rgb values, or hex codes.
</strong>
  <br> The color palette was used to show the colors that you see in many photos from the 70s. Bright reds, dulled yellows, oranges and greens. Jeans were also popular and that is where the blue comes in.
<br> https://www.colourlovers.com/palette/282196/That_70s_Show

<strong>3. Free Response: Summarize your work cycle for this assignment</strong>
  <br> This was a fun assignment. It shows that there are a lot of different options for adding color and other types of design pieces to your page. There is no one way or one code to follow. Which at this point is overwhelming, but also exciting. It means this truly is a creative design process and that's cool! 
