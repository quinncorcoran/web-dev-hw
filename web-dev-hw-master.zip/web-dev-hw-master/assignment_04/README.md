I went to http://ubl.com/. It was a simple site - white background, squares and blocks and simple text. No flashy lights, movies, or fun pictures. As of 2017, it is much more interactive. There are more colors, photos and videos. There are different ways to search for music - by genre, name, or band name.
As of today, the site cannot be found under that name.

With the GIT desktop, I found it to be simple and easy to use. It is a little confusing because it doesn't look like the website portal we've been working in, but all-in-all easy to understand.

![ScreenShot](images\assignment_04_Screenshot.png)
