# Assignment 2
## Skylar Vukasin
I am taking this class for a couple reasons. The first is the I need to fill sixteen credits of random courses and this is one that interested me. The second is I am intrigued by the internet, websites and the technicalities of web design, so I chose this course instead of, say, Art 101. 

1. How the internet works
2. How to use code and other tools to create websites
3. A better understanding of how websites and the internet work together and individually.

[Canva](https://www.canva.com/design/DADj-Yvkpuc/vkvOzRRtxcE-W8VJ3zykWg/edit)

[Responses](responses.txt)

![ScreenShot](images\assignment_02_Screenshot.png)
