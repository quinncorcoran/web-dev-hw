<strong>1. What is the difference between a system font, web font, and web-safe font?<strong>
  <br> <em>System fonts</em> are those on the currrent system(device) you are using, but most are not set up for web use.
  <br> <em> Web fonts </em> are fonts that are hosted on a server and do not have to be on the device to appear. Most websites use web fonts.
  <br> <em> Web-Safe Fonts</em> are fonts that are on both the web and most devices. These are font families that both Windows and Mac should have already installed.  

<strong>2. What is the importance of having fallback fonts or a font stack?</strong>
  <br> It is important to have a font that can be loaded by any device or system should the coded font fail to load for any number of reasons.

<strong>3. Free Response: Summarize your work cycle for this assignment</strong>
  <br> I got stuck a few times in this assignment. I wanted to try the different options for fonts and ended up getting more confused than it would have been to just do one piece at a time. I feel like I made the assignment harder than I should have. It was good to learn about fallback fonts specifically. That's not something I would have known or thought of. 
