1. Describe any forms you've come across while browsing the web. What purposes do the serve?
  
  Mostly I have seen contact forms. They normally want to capture contact information and email to send marketing materials and build their lists.  

2. List examples of a text, selection, and button input, and where they might be used.
  
  Text: Text input is as simple as it sounds. It's more of a fill in the blank type question or option where you are allowed to put in whatever you choose as long as it meets the max number of characters. 
  
  Selection: Selection input is like multiple choice tests in online courses. Where you cn only select one or more predetermined options.
  
  Button: Button is another self-explanatory one. It is a graphic that lets you click it to complete an action - most common one I can think of would be the Google "I'm feeling lucky" button.

3. Free Response: Summarize your work cycle for this assignment.
  
  This assignment proved to be surprisingly confusing for me.  As always, I went through it from the beginning and then following along the steps on the intro-web-dev website. I used Atom for all assignment pieces and built it out from there.
