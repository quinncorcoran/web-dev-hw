Briefly, browsers retrieve and display content like website, images, videos, etc. Basically, a way to access the internet from a device.  

Browsers I use: Google Chrome, Internet Explorer and Microsoft Edge

Markup Languages are HTML, XML, XHTML and are used to dictate the architecture of the page. They are the instructions for browsers to interpret to render text and graphics that make up webpages.

A commonly used element is the heading. There are 6 different headings that all start with the letter h and the number of the heading that has been chosen they end with the same thing but a forward slash before the letter to indicate the closing of the heading and end of that section. 

i.e. <  h1  > < / h 1 > 

![assignment_03_myfirstwebpage](/images/assignment_03_myfirstwebpage.png)
