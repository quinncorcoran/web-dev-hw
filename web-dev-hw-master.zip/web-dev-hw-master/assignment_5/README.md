How many main document <head> and <body> elements can a page have? How are these elements different, or what role do they play?
  You can have one main head document and one main body document. The head is the container for processing the information taht follows. It contains all high-level information about the site and always comes first. The body is where the meat of the site is places. it holds all the information that you want the site to have and show. It is within the body where structural and semantic markup are used.

Describe the difference between structural and semantic markup.
  Structural markup embeds information like headings, paragraphs, lists and line breaks. They are visually guiding and help people browse through the content of the page easily. They also help with screen readers.

  Symantec markup is used to edit the words on the page so-to-speak. It is a way to emphasize and focus on different things. Symantec markup is the way we make different words bold, italic, underlined and etc.

Free Response: Summarize your work cycle for this assignment.
  For this assignment, I started with creating the files I would need within Atom and then moving through the list of to-dos on Moodle. For the most part, it was an easy assignment. The only part that took some extra time was inserting the ingredients and directions lists. I liked learning about the difference in and how to use Symantec and Structural markup. I truly had no idea that was how things were done and it seems like a more complicated process prior to this lesson. My hardest part is still the inserting of photos. I always get stuck on those and need to find an easy way to remember how to do it. 
