<strong>1. Briefly recap your experience learning HTML. What was old, new, interesting, or difficult to learn? </strong>
  <br>The experience of learning HTML for me is ongoing. While I've learned a lot, I am in no way an expert and I'm looking forward to learning more and perfecting it. It is difficult but it is also interesting. I'm intrigued. I like it and want to get better at it.

<strong>2. Next module we begin CSS and expand on styling, which helps us "decorate" HTML. Is there anything you're anxious or excited to learn about in this new section?</strong>
  <br> I am incredibly excited to move into the "decorate" section of web design. I think this is where the creative side of people who design websites, code and more get to express themselves and build beautiful things for their clients.

<strong>3. Free Response: Summarize your work cycle for this assignment</strong>
  <br> As usual, this assignment was challenging, but in a different way. I was struggling with what to do my assignment on. I know a lot of things and feel like I can do a lot of things, but I am no expert at anything. I don't feel like I'm good enough at one thing to teach anyone. I followed the instructions on Moodle as well as the intro-web-des page and searched through the modules when I got stuck. I constantly find myself wishing these modules were available to me all the time - especially when this class ends - so when I am stuck, I can refer to these tips and step-by-step instructions. 
