<strong>1. Briefly describe the difference between divs, classes, ids and spans.</strong>
  <br><em>Divs</em> are used to create a clear structure and identify element groups. They are used to make the readability of the page better and easier.
 <br><em>Spans</em> are used to make parts of divs/text have a unique and different styling.
  <br><em>Classes</em> group similar types of elements together by using the same name. This makes it easy to style multiple pieces/groups all at once with one style edit.
  <br><em>Ids</em> are unique identifiers that basically give each item a different name. Ids are used to convey what the element is as short and easily as possible.

<strong>2. What is "alt text" and why do we use it?</strong>
  <br>"Alt Text" is alternative text - a required element used specifically on images to describe the image. It is primarily used as a description for screen readers for the visually impaired.

<strong>3. Free Response: Summarize your work cycle for this assignment.</strong>
  <br>For this assignment, I started in atom with a folder named "assignment_7". I then downloaded and moved the media files from Moodle to the assignment folder. After going through everyone on the intro-web-dev page, I moved forward in the assignment on Moodle.
 <br> I was interested to discover that Alt text is a required element - as I've been working in websites, I was always confused by the alt text and was never quite sure what it was for or what it should be. I had the title and alt text the same and now realize the changes I need to make.
  <br>I was confused for a moment in the assignment about which songs to use for the audio/video part. Originally, I had two different songs, but then realized I only need the one and three different pieces for it. My actual favorite song is too new to have a video, so I used the one I had heard most recently.
  <br>In this and many assignments, it would be nice to preview the changes that are being made and the page that (I assume) is being build. As in a WordPress site, you can click "preview changes" or something along those lines. It would be nice if that were available to kind of check the work quickly and see what's broken and needs to be changed. 
  <br> <em> Note</em> After further work, I discovered it was easy to check work by checking in on the live site link. So, revising this, it would be nice to be graded and have feedback as I'm unaware of how I'm doing in the class thus far and what I've been doing correctly/incorrectly instead of continuing blindly making the same mistakes. 
<br>It was interesting to learn about embedding the videos as multi-source and how to edit the paragraph stating the video was not supported. 
